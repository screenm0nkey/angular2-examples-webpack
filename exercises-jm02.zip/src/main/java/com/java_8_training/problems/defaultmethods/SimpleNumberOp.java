package com.java_8_training.problems.defaultmethods;

public interface SimpleNumberOp {

    int getValue();
}
