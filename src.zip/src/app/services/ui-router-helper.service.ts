import {Inject, Injectable} from '@angular/core';

@Injectable()
export class UIRouterHelperService {

  constructor(@Inject('$state') private uiState: IStateService) {
  }

  go(path: string): void {
    console.log(`%croute "${path}"`, 'color:deeppink');
    this.uiState.go(path);
  }

}
