package com.java_8_training.examples.design.builder;

interface TitleBuilder {
    ContentBuilder title(String title);
}
