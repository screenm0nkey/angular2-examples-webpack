package com.java_8_training.examples.datetime;

import java.time.*;
import java.util.List;

public class SecondExamples {

    public boolean tomorrowIsAfterToday() {
        return false;
    }

    public DayOfWeek getLastDayOfMonth() {
        return null;
    }

    //Longest day of year June 21st
    public int howManyDaysUntilLongestDayOfTheYear() {
        return 0;
    }

    public LocalDate createDateFromJavaUtilDate() {
        return null;
    }

    public List<DayOfWeek> lastDaysOfMonthsInYear(int year) {
        return null;
    }
}
