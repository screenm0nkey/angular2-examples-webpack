package com.java_8_training.examples.design.template;

public class Customer {
}
