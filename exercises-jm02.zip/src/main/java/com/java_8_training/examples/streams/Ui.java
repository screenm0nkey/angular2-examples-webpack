package com.java_8_training.examples.streams;

public class Ui
{
    static void displayCheckIn(final Booking booking)
    {
        System.out.println("Checking in ... " + booking);
    }

    static void displayMissingBookingPage()
    {
        System.out.println("Missing Booking");
    }
}

