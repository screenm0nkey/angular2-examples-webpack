angular.module('hybridApp')
  .directive('listItem', ['ng2LogService', function (ng2LogService) {
    return {
      restrict: 'E',
      templateUrl: '/ng1/section-one/list-item.html',
      scope: {
        'item': "="
      },
      link: function (scope) {
        scope.removeItem = function () {
          ng2LogService.log('Hide List Item');
          scope.item.hidden = !scope.item.hidden;
        }
      }
    }
  }]);
