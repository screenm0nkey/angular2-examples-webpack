import {Component} from '@angular/core';

@Component({
  selector: 'ng2-section-two',
  template: `<h2>Section Two is an <span class="ng2">[ng2-component]</span></h2>`,
  styleUrls: ['./section-two.scss']
})
export class SectionTwoComponent {
}


