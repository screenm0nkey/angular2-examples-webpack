import {downgradeComponent, downgradeInjectable} from '@angular/upgrade/static';
import {FactoryProvider} from '@angular/core';

declare var angular: any;

export interface IComponentUpgradeOptions {
  inputs?: string[];
  outputs?: string[];
}

export interface IHybridHelper {
  moduleName?: string;

  ng1module(moduleName: string): IHybridHelper;

  downgradeComponent(componentSelector: string, componentClass: any, options?: IComponentUpgradeOptions): IHybridHelper;

  downgradeProvider(providerName: string, providerClass: any): IHybridHelper;

  upgradeProvider(ng1Name: string, ng2Name?: string): FactoryProvider;
}

const buildFactoryForUpgradeProvider =
  (name: string): Function => (injector: any) => injector.get(name);

export const hybridHelper: IHybridHelper = {
  ng1module: (moduleName: string): IHybridHelper => {
    hybridHelper.moduleName = moduleName;
    return hybridHelper;
  },

  downgradeComponent: (componentName: string, componentClass: any, options?: IComponentUpgradeOptions): IHybridHelper => {
    if (!hybridHelper.moduleName) {
      throw new Error('Please initialise hybridHelper.ng1module("ng1ModuleName")');
    }
    options = options || {};
    const inputs = options.inputs || [];
    const outputs = options.outputs || [];
    const component = componentClass;

    angular.module(hybridHelper.moduleName).directive(componentName, downgradeComponent({
      component, inputs, outputs
    }) as angular.IDirectiveFactory);

    return hybridHelper;
  },

  downgradeProvider: (providerName: string, providerClass: any): IHybridHelper => {
    angular.module(hybridHelper.moduleName).factory(providerName, downgradeInjectable(providerClass));
    return hybridHelper;
  },

  upgradeProvider: (ng1Name: string, ng2Name?: string): FactoryProvider => {
    ng2Name = ng2Name || ng1Name;
    return {
      provide: ng2Name,
      useFactory: buildFactoryForUpgradeProvider(ng1Name),
      deps: ['$injector']
    };
  }
};
