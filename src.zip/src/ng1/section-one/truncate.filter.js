angular.module('hybridApp')
  .filter('truncate', function () {
    return function (input, len) {
      if (input.length > len) {
        return input.substring(0, len).trim() + "...";
      }
      return input;
    }
  });
