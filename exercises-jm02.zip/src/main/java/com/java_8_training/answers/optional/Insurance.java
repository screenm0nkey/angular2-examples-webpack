package com.java_8_training.answers.optional;

public class Insurance {


    public Insurance(String name){
        this.name = name;
    }

    private String name;

    public String getName() {
        return name;
    }
}
