import {NgModule}           from '@angular/core';
import {CommonModule}       from '@angular/common';
import {FormsModule}        from '@angular/forms';
import {AwesomePipe}        from './awesome.pipe';
import {ContactComponent}   from './contact.component';
import {ContactService}     from './contact.service';
import {HighlightDirective} from './highlight.directive';
import {UserService} from '../user.service';

@NgModule({
    // even though CommonModule is imported in app.module, it's not accessible
    // in this module's components. we have to import it here too!!
    // Modules do not inherit access to the components, directives or pipes
    // that are declared in other modules. What AppModule imports is irrelevant
    // to ContactModule and vice versa.
    imports: [CommonModule, FormsModule],
    // these are the  components, directives, and pipes used for this module.
    // they are not accessible elsewhere in the app. use 'exports' for that.
    declarations: [ContactComponent, HighlightDirective, AwesomePipe],
    // We export the ContactComponent so other modules that import the ContactModule
    // can include it in their component templates.
    // if we don't export ContactComponent the app.component won't be able to use it.
    exports: [ContactComponent],
    // these have a global scope as all modules share the same injector. so we could
    // provide UserService here and remove it from the app.module and it would still work
    providers: [ContactService]
})
export class ContactModule {
}
