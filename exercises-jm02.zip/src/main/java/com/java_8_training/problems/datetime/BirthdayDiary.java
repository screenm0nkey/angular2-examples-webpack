package com.java_8_training.problems.datetime;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.Month;
import java.time.Year;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class BirthdayDiary {

    private Map<String, LocalDate> birthdays;

    public BirthdayDiary() {
        birthdays = new HashMap<>();
    }

    public LocalDate addBirthday(String name, int day, int month, int year) {
        return null;
    }

    public LocalDate getBirthdayFor(String name) {
        return birthdays.get(name);
    }

    public int getAgeInYear(String name, int year) {
        return 0;
    }

    public Set<String> getFriendsOfAgeIn(int age, int year) {
        return null;
    }

    public Set<String> getBirthdaysIn(Month month) {
        return null;
    }

    // Age here means the age of your birthday in a given year. So if this year is your 35th birthday
    // then your age in that year is 35.
    public int getTotalAgeInYears() {
        return -1;
    }
}