package com.java_8_training.examples.design.builder;

interface ContentBuilder {
    Message content(String content);
}
