package com.java_8_training.examples.streams;

public enum  Tag {
    FOOD, ENTERTAINMENT, TRAVEL, UTILITY;
}
