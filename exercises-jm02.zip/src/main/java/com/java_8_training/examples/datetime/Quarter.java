package com.java_8_training.examples.datetime;

/**
 * Created by jpgough on 20/01/2014.
 */
enum Quarter {
    FIRST, SECOND, THIRD, FOURTH;
}
