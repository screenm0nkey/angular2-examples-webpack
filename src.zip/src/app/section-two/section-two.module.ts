import {NgModule} from '@angular/core';
import {SectionTwoComponent} from './section-two.component';
import {hybridHelper} from '../services/ng-upgrade-helper';

hybridHelper.ng1module('hybridApp')
  .downgradeComponent('ng2SectionTwo', SectionTwoComponent);

const downgradedNg2Components = [
  SectionTwoComponent
];

@NgModule({
  imports: [],
  providers: [],
  declarations: [
    ...downgradedNg2Components
  ],
  entryComponents: [
    ...downgradedNg2Components
  ]
})
export class SectionTwoModule {
}
