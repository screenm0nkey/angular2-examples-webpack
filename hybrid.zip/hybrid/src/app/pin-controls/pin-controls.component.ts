import {
  Component,
  Input,
  Output,
  EventEmitter
} from '@angular/core';

@Component({
  selector: 'pin-controls',
  template: `<div class="controls">
    <div class="heart">
      <a (click)="toggleFav()">
        <img src="/assets/images/icons/Heart-Empty.png" *ngIf="!pin.faved" />
        <img src="/assets/images/icons/Heart-Red.png"   *ngIf="pin.faved" />
      </a>
    </div>
  </div>`
})
export class PinControlsComponent {
  @Input() pin: Pin;
  @Output() faved: EventEmitter<Pin> = new EventEmitter<Pin>();

  toggleFav(): void {
    this.faved.emit(this.pin);
  }
}
