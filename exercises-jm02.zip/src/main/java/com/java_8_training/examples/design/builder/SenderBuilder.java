package com.java_8_training.examples.design.builder;

interface SenderBuilder {
    TitleBuilder sender(Sender sender);
}