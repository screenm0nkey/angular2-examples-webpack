angular.module('hybridApp')
  .service('ListDataService', ['$http', '$q', function ($http, $q) {
    this._data = null;

    this.getData = function () {
      var self = this;
      if (self._data == null) {
        // initialize with sample data
        return $http.get("/assets/data/sample-data.json").then(
          function (response) {
            self._data = response.data;
            return self._data;
          });
      } else {
        return $q.when(self._data);
      }
    };
  }]);
