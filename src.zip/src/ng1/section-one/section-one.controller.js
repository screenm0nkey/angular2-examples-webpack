angular.module('hybridApp')
  .controller('SectionOneController', ['items', 'ng2LogService', function (items, ng2LogService) {
    ng2LogService.log('SectionOneController Visited');
    this.items = items;
  }]);








