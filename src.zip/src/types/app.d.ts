type IStateService = angular.ui.IStateService;

interface ListItem {
  title: string;
  id: string;
  hidden: boolean;
}

// ng1 service
interface ListDataService {
  getData(): Promise<ListItem[]>;
}

