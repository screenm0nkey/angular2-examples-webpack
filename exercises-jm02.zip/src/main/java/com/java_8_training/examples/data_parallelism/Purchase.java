package com.java_8_training.examples.data_parallelism;

/**
 * .
 */
public class Purchase {

    private final int cost;

    public Purchase(int cost) {
        this.cost = cost;
    }

    public int getCost() {
        return cost;
    }
}
