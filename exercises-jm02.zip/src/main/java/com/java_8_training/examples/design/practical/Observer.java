package com.java_8_training.examples.design.practical;

/**
 * .
 */
public interface Observer {

    void onAlert(String room);

}
