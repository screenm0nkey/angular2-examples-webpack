angular.module('hybridApp')
  .config(['$locationProvider','$stateProvider', '$urlRouterProvider', function ($locationProvider, $stateProvider, $urlRouterProvider) {
    $locationProvider.html5Mode(false);

    $stateProvider
      .state('home', {
        templateUrl: '/ng1/app.html',
        url: '/home'
      })
      .state('section-one', {
        templateUrl: '/ng1/section-one/section-one.html',
        controller: 'SectionOneController as vm',
        url: '/section-one',
        resolve: {
          items: function (ListDataService) {
            return ListDataService.getData();
          }
        }
      })
      .state('section-two', {
        templateUrl: '/ng1/section-two/section-two.html',
        url: '/section-two',
        resolve: {
          items: function (ListDataService) {
            return ListDataService.getData();
          }
        }
      });

    $urlRouterProvider.otherwise('/home');

  }]);
