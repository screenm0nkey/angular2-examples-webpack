angular.module('hybridApp', [
  'ui.router'
]);
