import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'list-item-controls',
  template: `<a href="#" (click)="removeItem()">Remove</a>`
})
export class ListItemControlsComponent {
  @Input() item: ListItem;
  @Output() remove: EventEmitter<string> = new EventEmitter<string>();

  removeItem(): void {
    this.remove.emit(this.item.id);
  }
}
