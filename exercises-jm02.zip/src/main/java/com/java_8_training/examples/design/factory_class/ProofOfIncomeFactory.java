package com.java_8_training.examples.design.factory_class;

public interface ProofOfIncomeFactory {

    ProofOfIncome present(Applicant applicant);

}
