import {Injectable} from '@angular/core';

/**
 * This is a test service to show how a service can be downgraded for use in ng1.
 */
@Injectable()
export class LogService {
  events: string[] = [];

  public log(event: string): void {
    console.log(`ng2 service: ${event}`);
    this.events.push(event);
  }
}
