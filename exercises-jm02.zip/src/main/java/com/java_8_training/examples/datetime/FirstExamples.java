package com.java_8_training.examples.datetime;

import java.time.*;

public class FirstExamples {

    //Create a simple Date - Henry VIII Birthday - June 28th 1491
    public LocalDate getHenrysBirthday() {
        return null;
    }

    //Create a simple Time - 13:51
    public LocalTime getSampleLocalTime() {
        return null;
    }

    //Create a sample LocalDateTime of the above
    public LocalDateTime getSampleLocalDateTime() {
        return null;
    }

    public LocalDateTime getComponentDateTime() {
        return null;
    }

    public LocalDate getTodayFromLocalDateTime() {
        return null;
    }

    public int getDifferenceBetweenParisAndLondon() {
        return 0;
    }
}
