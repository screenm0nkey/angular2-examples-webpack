import {Component} from '@angular/core';
import {UIRouterHelperService} from './services/ui-router-helper.service';

@Component({
  selector: 'app-navigation',
  template: `
    <ul>
      <a href="#" (click)="ui.go('home')">Home</a>
      <a href="#" (click)="ui.go('section-one')">Section One</a>
      <a href="#" (click)="ui.go('section-two')">Section Two</a>
    </ul>
  `
})
export class AppNavigationComponent {
  constructor(private ui: UIRouterHelperService) {
  }
}
