package com.java_8_training.examples.datetime;

import java.time.LocalDate;

public class FormattingExamples {

    public String formatSimpleDate() {
        return null;
    }

    //MM/DD/yyyy
    public String formatMonthDayYear() {
        return null;
    }

    public LocalDate parseLocalDate(String dateString) {
        return null;
    }
}
