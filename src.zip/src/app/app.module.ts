import {NgModule} from '@angular/core';
import {UpgradeModule} from '@angular/upgrade/static';
import {BrowserModule} from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpClientModule} from '@angular/common/http';

import {AppHeaderComponent} from './app-header.component';
import {AppNavigationComponent} from './app-navigation.component';
import {SectionTwoModule} from './section-two/section-two.module';
import {ListItemControlsComponent} from './item-controls/item-controls.component';
import {LogService} from './services/log.service';
import {UIRouterHelperService} from './services/ui-router-helper.service';
import {hybridHelper} from './services/ng-upgrade-helper';

declare var angular: any;

// downgrade ng2 content to be used in ng1
hybridHelper.ng1module('hybridApp')
  .downgradeComponent('appHeader', AppHeaderComponent)
  .downgradeComponent('listItemControls', ListItemControlsComponent)
  .downgradeComponent('appNavigation', AppNavigationComponent)
  .downgradeProvider('ng2LogService', LogService);

// upgrade ng1 services to be used in ng2
const upgradedNg1Services = [
  hybridHelper.upgradeProvider('ListDataService'),
  hybridHelper.upgradeProvider('$state')
];

const downgradedNg2Components = [
  AppHeaderComponent,
  AppNavigationComponent,
  ListItemControlsComponent
];

@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    SectionTwoModule,
    UpgradeModule,
    SectionTwoModule
  ],
  declarations: [
    ...downgradedNg2Components
  ],
  entryComponents: [
    ...downgradedNg2Components
  ],
  providers: [
    UIRouterHelperService,
    LogService,
    ...upgradedNg1Services
  ]
})
export class AppModule {
  constructor(private upgrade: UpgradeModule) {
  }

  ngDoBootstrap() {
  }
}


