package com.java_8_training.problems.lambdas;


public interface TextFormatter {
    String format(String s);

}
