package com.java_8_training.examples.design.template;

/**
 * .
 */
public class Database {
    public static Customer getCustomerWithId(int id) {
        return new Customer();
    }
}
