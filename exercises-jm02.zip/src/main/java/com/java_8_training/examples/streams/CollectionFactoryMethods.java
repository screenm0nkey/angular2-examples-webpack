package com.java_8_training.examples.streams;

public class CollectionFactoryMethods {

    public static void main(String[] args) {
        // List.of()
        // Set.of()
        // Map.of()
    }
}
