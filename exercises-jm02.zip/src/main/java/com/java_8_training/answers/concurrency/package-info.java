package com.java_8_training.answers.concurrency;

/**
 * The API gets refactored to CallbackArtistAnalyzer and
 * the code to CompletableFutureArtistAnalyser.
 */