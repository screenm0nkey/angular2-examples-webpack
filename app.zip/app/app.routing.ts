import { ModuleWithProviders }  from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

export const routes: Routes = [
    { path: '', redirectTo: 'contact', pathMatch: 'full'},
    { path: 'crisis', loadChildren: 'app/crisis/crisis.module#CrisisModule' },
    { path: 'heroes', loadChildren: 'app/hero/hero.module#HeroModule' }
];
// This routing object is intended for the app root module only.
// Never call RouterModule.forRoot in a feature module.
export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
